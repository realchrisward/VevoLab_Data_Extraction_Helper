# -*- coding: utf-8 -*-
"""
VDEH Tests

"""

__component_version__ = "0.1"
__license__ = "MIT License"

# good VevoLab File and Settings for Extraction

# good VevoLab File and Settings for Extraction and Analysis

# good VevoLab File with bad Settings File

    # animal metadata incomplete - ?function to allow user to test this?
    
    # model references columns not present in metadata
    
    # derived data references columns not present in metadata
    
    # Settings File includes extra sheets, settings
    
    # ...
    
"""
This is where I would put my tests...If I had any!
"""