# -*- coding: utf-8 -*-
"""
VDEH_subgui_controller

"""

__component_version__ = "1.0"
__license__ = "MIT License"


#%% import modules/libraries


#%% define functions


#%% define classes


